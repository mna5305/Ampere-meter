# AmpereFlow
Live battery monitor (Kotlin + Jetpack Compose).
Push to GitHub -> Actions tab -> "Build APK" -> download artifact `AmpereFlow-debug-apk`.
