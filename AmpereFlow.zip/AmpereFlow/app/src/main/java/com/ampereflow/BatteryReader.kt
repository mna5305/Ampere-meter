package com.ampereflow

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.abs

data class BatteryState(
    val level: Int = 0,
    val mA: Int = 0,
    val mV: Int = 0,
    val tempC: Float = 0f,
    val charging: Boolean = false,
    val plugged: String = "None",
    val status: String = "Unknown",
    val healthLabel: String = "Good",
    val estimatedMah: Int = 0,
    val designMah: Int = 0,
    val minMa: Int = 0,
    val maxMa: Int = 0,
    val maxW: Float = 0f,
    val tech: String = "Li-ion",
    val currentHistory: List<Float> = emptyList(),
) {
    val watts: Float get() = abs(mA) * mV / 1_000_000f
    val healthPct: Int
        get() = if (designMah > 0 && estimatedMah > 0)
            (estimatedMah * 100 / designMah).coerceAtMost(100) else 0
}

class BatteryReader(private val ctx: Context) {
    private val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    private val design = designCapacity()
    private var minMa = Int.MAX_VALUE
    private var maxMa = 0
    private var maxW = 0f
    private val history = ArrayDeque<Float>()

    fun read(): BatteryState {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (scale > 0) level * 100 / scale else level
        val mV = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val statusInt = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugInt = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val healthInt = i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0) ?: 0
        val tech = i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Li-ion"

        val charging = statusInt == BatteryManager.BATTERY_STATUS_CHARGING ||
            statusInt == BatteryManager.BATTERY_STATUS_FULL
        // Raw value is microamps on most phones, milliamps on a few
        var raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        if (abs(raw) > 20_000) raw /= 1000
        // Sign differs between manufacturers, so force it from charge status
        val mA = if (charging) abs(raw) else -abs(raw)

        val counterUah = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        val estimated = if (counterUah > 0 && pct >= 5) (counterUah / 1000f / (pct / 100f)).toInt() else 0

        val a = abs(mA)
        if (a > 0) minMa = minOf(minMa, a)
        maxMa = maxOf(maxMa, a)
        val w = a * mV / 1_000_000f
        maxW = maxOf(maxW, w)
        history.addLast(a.toFloat()); if (history.size > 30) history.removeFirst()

        return BatteryState(
            level = pct, mA = mA, mV = mV, tempC = temp, charging = charging,
            plugged = when (plugInt) {
                BatteryManager.BATTERY_PLUGGED_AC -> "AC"
                BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
                else -> "None"
            },
            status = when (statusInt) {
                BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
                BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
                BatteryManager.BATTERY_STATUS_FULL -> "Full"
                BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
                else -> "Unknown"
            },
            healthLabel = when (healthInt) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
                BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
                BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
                else -> "Good"
            },
            estimatedMah = estimated, designMah = design,
            minMa = if (minMa == Int.MAX_VALUE) 0 else minMa, maxMa = maxMa, maxW = maxW,
            tech = tech, currentHistory = history.toList(),
        )
    }

    // Design capacity is hidden in the framework; read it by reflection
    private fun designCapacity(): Int = try {
        val c = Class.forName("com.android.internal.os.PowerProfile")
        val o = c.getConstructor(Context::class.java).newInstance(ctx)
        (c.getMethod("getBatteryCapacity").invoke(o) as Double).toInt()
    } catch (e: Throwable) { 0 }
}
