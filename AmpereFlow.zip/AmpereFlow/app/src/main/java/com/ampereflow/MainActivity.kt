package com.ampereflow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

private val Bg = Color(0xFF080B10)
private val CardBg = Color(0xFF0F141B)
private val Stroke1 = Color(0xFF1E2733)
private val Cyan = Color(0xFF22E3FF)
private val Green = Color(0xFF2EE66B)
private val Yellow = Color(0xFFFFD43B)
private val Dim = Color(0xFF7D8896)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val reader = BatteryReader(applicationContext)
        setContent {
            var state by remember { mutableStateOf(reader.read()) }
            LaunchedEffect(Unit) { while (true) { state = reader.read(); delay(1000) } }
            var tab by remember { mutableStateOf(0) }
            Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
                Box(Modifier.weight(1f)) {
                    if (tab == 0) SpeedScreen(state) else Placeholder(Tabs[tab].label)
                }
                BottomBar(tab) { tab = it }
            }
        }
    }
}

private data class TabItem(val label: String, val icon: ImageVector)
private val Tabs = listOf(
    TabItem("Speed", Icons.Default.Speed), TabItem("Chart", Icons.Default.ShowChart),
    TabItem("Sessions", Icons.Default.History), TabItem("Usage", Icons.Default.BarChart),
    TabItem("AOD", Icons.Default.NightsStay), TabItem("Settings", Icons.Default.Settings),
)

@Composable private fun Placeholder(name: String) {
    Box(Modifier.fillMaxSize(), Alignment.Center) { Text("$name coming soon", color = Dim, fontSize = 16.sp) }
}

@Composable private fun BottomBar(sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF0B1017)).navigationBarsPadding().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly) {
        Tabs.forEachIndexed { i, t ->
            val on = i == sel
            Column(Modifier.clickable { onSel(i) }.padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.clip(RoundedCornerShape(16.dp)).background(if (on) Cyan.copy(alpha = .12f) else Color.Transparent)
                    .padding(horizontal = 18.dp, vertical = 6.dp)) {
                    Icon(t.icon, null, tint = if (on) Cyan else Dim, modifier = Modifier.size(24.dp))
                }
                Text(t.label, color = if (on) Cyan else Dim, fontSize = 11.sp)
            }
        }
    }
}

@Composable private fun Panel(modifier: Modifier = Modifier, border: Color = Stroke1, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.clip(RoundedCornerShape(24.dp)).background(CardBg)
        .border24(border).padding(16.dp), content = content)
}
private fun Modifier.border24(c: Color) = this.border(BorderStroke(1.dp, c), RoundedCornerShape(24.dp))

private fun f(v: Float, d: Int = 1) = String.format(Locale.US, "%.${d}f", v)

@Composable private fun SpeedScreen(s: BatteryState) {
    val levelColor = Yellow
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column {
            Text("AmpereFlow: Battery Master", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Safe Charging • Live Speed & Health", color = Dim, fontSize = 14.sp)
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Green.copy(alpha = .08f))
            .border24(Green.copy(alpha = .5f)).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(Green))
            Spacer(Modifier.width(10.dp))
            Text("Monitoring Active", color = Green, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        }
        Box(Modifier.fillMaxWidth(), Alignment.Center) {
            Row(Modifier.clip(RoundedCornerShape(50)).background(CardBg).border24(Stroke1)
                .padding(horizontal = 24.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Bolt, null, tint = Yellow, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(s.status, color = Yellow, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Panel(Modifier.weight(1f).height(120.dp)) {
                Gauge(s.watts / 20f, f(s.watts), "WATTS", 80.dp, Green, 20.sp)
            }
            Panel(Modifier.weight(1.45f).height(150.dp), border = Yellow.copy(alpha = .6f)) {
                Gauge(s.level / 100f, "${s.level}%", "BATTERY", 110.dp, Cyan, 26.sp, Yellow, "Health: ${s.healthLabel}")
            }
            Panel(Modifier.weight(1f).height(120.dp)) {
                Gauge(kotlin.math.abs(s.mA) / 3000f, "${s.mA}", "mA", 80.dp, Green, 18.sp, Yellow)
            }
        }
        Panel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(width = 40.dp, height = 24.dp).clip(RoundedCornerShape(6.dp)).border24(Dim).padding(3.dp)) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(s.level / 100f).background(Cyan))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("BATTERY LEVEL", color = Dim, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(if (s.charging) "Charging" else "Discharging on Battery", color = Color.White, fontSize = 16.sp)
                }
                Text("${s.level}%", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)).background(Stroke1)) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(s.level / 100f).background(Cyan))
            }
            Spacer(Modifier.height(12.dp))
            Row {
                Text("${s.mA} mA • ${f(s.watts)} W", color = Color(0xFFB8C2CC), modifier = Modifier.weight(1f))
                Text("${s.mV} mV • ${f(s.tempC)}°C", color = Dim)
            }
        }
        Panel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Favorite, null, tint = Green, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Battery Health", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text("${s.healthPct}%", color = Green, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(10.dp))
                Text(if (s.healthPct >= 80) "Excellent" else "Worn", color = Green, fontSize = 18.sp,
                    modifier = Modifier.padding(bottom = 6.dp))
            }
            Text("Measured from charge counter & design profile", color = Dim, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF0A0E13)).padding(16.dp)) {
                Stat("ESTIMATED", "${s.estimatedMah} mAh", Modifier.weight(1f))
                Stat("DESIGN", "${s.designMah} mAh", Modifier.weight(1f))
            }
        }
        Panel(Modifier.fillMaxWidth()) {
            Text("Charging Power by Level", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text("Plug in and charge through battery levels to map your charger's real taper curve.",
                color = Dim, fontSize = 14.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("TEMPERATURE", f(s.tempC), "°C", if (s.tempC < 40) "NORMAL" else "HOT", Modifier.weight(1f))
            Tile("VOLTAGE", f(s.mV / 1000f, 2), "V", "${s.mV} mV", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("CURRENT", "${s.mA}", "mA", null, Modifier.weight(1f), s.currentHistory, Yellow)
            Tile("MAX POWER", f(s.maxW), "W", "Now ${f(s.watts)}W", Modifier.weight(1f), s.currentHistory, Cyan)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("PLUGGED", s.plugged, "", null, Modifier.weight(1f))
            Tile("MAX CAPACITY", "${s.estimatedMah}", "mAh", s.tech, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("CHARGE STATUS", s.status, "", null, Modifier.weight(1f))
            Tile("MIN / MAX MA", "${s.minMa}", "/ ${s.maxMa}", null, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable private fun Stat(label: String, value: String, m: Modifier) {
    Column(m, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Dim, fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun Tile(title: String, value: String, unit: String, badge: String?, m: Modifier,
                             spark: List<Float> = emptyList(), sparkColor: Color = Cyan) {
    Panel(m.height(112.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Dim, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f))
            if (badge != null) Text(badge, color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Cyan.copy(alpha = .12f)).padding(horizontal = 8.dp, vertical = 4.dp))
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            if (unit.isNotEmpty()) { Spacer(Modifier.width(6.dp)); Text(unit, color = Dim, fontSize = 14.sp, modifier = Modifier.padding(bottom = 4.dp)) }
        }
        if (spark.size > 1) {
            Canvas(Modifier.fillMaxWidth().weight(1f).padding(top = 6.dp)) {
                val mx = (spark.maxOrNull() ?: 1f).coerceAtLeast(1f)
                val p = Path()
                spark.forEachIndexed { i, v ->
                    val x = size.width * i / (spark.size - 1)
                    val y = size.height * (1f - v / mx)
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                drawPath(p, sparkColor, style = Stroke(width = 3f, cap = StrokeCap.Round))
            }
        }
    }
}

@Composable private fun Gauge(frac: Float, big: String, label: String, dia: Dp, arc: Color, bigSp: androidx.compose.ui.unit.TextUnit,
                              bigColor: Color = Color.White, sub: String? = null) {
    Box(Modifier.size(dia), Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = size.minDimension * 0.07f
            val inset = sw / 2
            val a = Size(this.size.width - sw, this.size.height - sw)
            drawArc(Stroke1, 135f, 270f, false, Offset(inset, inset), a, style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(Brush.sweepGradient(listOf(Cyan, arc, Cyan)), 135f, 270f * frac.coerceIn(0.01f, 1f), false,
                Offset(inset, inset), a, style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(big, color = bigColor, fontSize = bigSp, fontWeight = FontWeight.Bold)
            Text(label, color = Dim, fontSize = 11.sp)
            if (sub != null) Text(sub, color = Green, fontSize = 10.sp)
        }
    }
}
